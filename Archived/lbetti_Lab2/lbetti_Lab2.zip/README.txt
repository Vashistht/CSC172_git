Lab 02:

Name: Livia Betti
Student ID: 31568890
Email: lbetti@u.rochester.edu
Partner: Vashisth Tiwari

Lab2 is a class with methods to print an array and to get the max element of an array.

printArrayNonGen is a method with an array of Objects as a parameter that prints the array.
The printArray methods use method overloading to print the array (different methods depending on the type).
Therefore, there is a printArray method which takes in an Integer array.
There is a printArray method which takes in a Double array.
There is a prinArray method which takes in a Character array.
And, there is a printArray method which takes in a String array.
printArrayGen is a method that uses generics to support each array type and print the array.
getMax is a method that takes a Comparable type and returns the maximum element of the array.
getMaxGen is a method which uses generics to support the array type and returns the maximum element of the array.

The main method declares 4 different arrays, as stated in the sample input.
It then goes through and prints the different methods.
To test this, just change the array of the respective type in the main method.
Note that Alex said we could just print the test cases instead of using the Scanner.
Thank you!